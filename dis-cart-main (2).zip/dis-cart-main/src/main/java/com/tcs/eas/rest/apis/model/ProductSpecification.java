package com.tcs.eas.rest.apis.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel
@Data
public class ProductSpecification {

    private String specificationdescription;
}
