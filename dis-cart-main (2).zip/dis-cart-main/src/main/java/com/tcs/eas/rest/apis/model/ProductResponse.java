package com.tcs.eas.rest.apis.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel
@Data
public class ProductResponse {

    private int productId;
    private String productName;
    private String productDescription;
    private String brand;
    private String productCategory;
    private String image;
    private int availableQuantity;
    private int minimumQuantity;
    private String currency;
    private String storeId;
    private Double price;
    private int productCategoryId;
    private int productReviewCnt;
    private Double productReviewStars;
    private ProductSpecification productSpecification;
    private String mfgDate;
}
