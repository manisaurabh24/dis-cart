package com.tcs.eas.rest.apis.model;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartProductUpdateResponse {
    private int productId;
    private int offerId;
    private String productName;
    private int productQuantity;
    private int availableQuantity;
    private double productPrice;
}
