package com.tcs.eas.rest.apis.model;

public enum DeliveryType {
    FREE, PAID;
}
