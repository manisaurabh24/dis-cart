package com.tcs.eas.rest.apis.model;

public enum PaymentType {
    GPAY, PHONEPE, PAYTM, AMAZON_PAY, COD;
}
