package com.tcs.eas.rest.apis.model;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartUpdateResponse {
    private int cartId;
    private int userId;
    private String date;
    private int cartQuantity;
    private List<CartProductUpdateResponse> cartProductUpdateResponseList;
}
