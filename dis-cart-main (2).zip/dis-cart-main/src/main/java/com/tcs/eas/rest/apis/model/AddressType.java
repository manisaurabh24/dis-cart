package com.tcs.eas.rest.apis.model;

public enum AddressType {
    HOME, OFFICE
}
